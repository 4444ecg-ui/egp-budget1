package com.example.budget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MonthStat(val month: String, val usd: Double, val egp: Double, val count: Int)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("budget", Context.MODE_PRIVATE)
    fun month(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun colorFor(pct: Int): Int = when {
        pct >= 85 -> 0xFFC62828.toInt()
        pct >= 60 -> 0xFFEF6C00.toInt()
        else -> 0xFF2E7D32.toInt()
    }
    fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)

    fun limit(c: Context): Double = p(c).getString("limit", "0")!!.toDouble()
    fun setLimit(c: Context, v: Double) = p(c).edit().putString("limit", v.toString()).apply()

    private fun all(c: Context) = JSONArray(p(c).getString("exp", "[]"))
    private fun save(c: Context, a: JSONArray) = p(c).edit().putString("exp", a.toString()).apply()

    fun add(c: Context, egp: Double, rate: Double, date: String) {
        val a = all(c)
        a.put(JSONObject().put("egp", egp).put("rate", rate).put("usd", egp / rate)
            .put("date", date).put("month", date.substring(0, 7)))
        save(c, a)
    }

    fun removeLast(c: Context) {
        val a = all(c)
        if (a.length() == 0) return
        val n = JSONArray()
        for (i in 0 until a.length() - 1) n.put(a.get(i))
        save(c, n)
    }

    fun spentUsd(c: Context): Double {
        val a = all(c); val m = month(); var s = 0.0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("month") == m) s += o.getDouble("usd")
        }
        return s
    }

    fun spentEgp(c: Context): Double {
        val a = all(c); val m = month(); var s = 0.0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("month") == m) s += o.getDouble("egp")
        }
        return s
    }

    fun lines(c: Context): List<String> {
        val a = all(c); val m = month()
        val rows = ArrayList<JSONObject>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("month") == m) rows.add(o)
        }
        return rows.sortedByDescending { it.getString("date") }.map { o ->
            o.getString("date").substring(5) + "   " + fmt(o.getDouble("egp")) +
                " ج.م  =  $" + fmt(o.getDouble("usd")) + "   (سعر " + fmt(o.getDouble("rate")) + ")"
        }
    }

    fun monthTotals(c: Context): List<MonthStat> {
        val a = all(c)
        val m = java.util.TreeMap<String, DoubleArray>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val arr = m.getOrPut(o.getString("month")) { DoubleArray(3) }
            arr[0] += o.getDouble("usd"); arr[1] += o.getDouble("egp"); arr[2] += 1.0
        }
        return m.map { MonthStat(it.key, it.value[0], it.value[1], it.value[2].toInt()) }
    }

    fun cachedRate(c: Context): Pair<String, Double>? {
        val d = p(c).getString("rateDate", null) ?: return null
        return d to p(c).getString("rate", "0")!!.toDouble()
    }

    fun rateFor(c: Context, date: String): Double? = p(c).getString("r_" + date, null)?.toDoubleOrNull()
    fun saveRateFor(c: Context, date: String, r: Double) = p(c).edit().putString("r_" + date, r.toString()).apply()

    fun saveRate(c: Context, r: Double) =
        p(c).edit().putString("rateDate", today()).putString("rate", r.toString()).apply()
}

object Rates {
    /** Returns (EGP per 1 USD, isFromToday). Call from a background thread. */
    fun get(c: Context): Pair<Double, Boolean>? {
        val cached = Store.cachedRate(c)
        if (cached != null && cached.first == Store.today()) return cached.second to true
        return try {
            val conn = URL("https://open.er-api.com/v6/latest/USD").openConnection() as HttpURLConnection
            conn.connectTimeout = 8000; conn.readTimeout = 8000
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val r = j.getJSONObject("rates").getDouble("EGP")
            Store.saveRate(c, r)
            r to true
        } catch (e: Exception) {
            cached?.let { it.second to false }
        }
    }

    /** EGP per 1 USD on a past date. Call from a background thread. */
    fun forDate(c: Context, date: String): Pair<Double, Boolean>? {
        if (date == Store.today()) return get(c)
        Store.rateFor(c, date)?.let { return it to true }
        val urls = listOf(
            "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@" + date + "/v1/currencies/usd.json",
            "https://" + date + ".currency-api.pages.dev/v1/currencies/usd.json")
        for (u in urls) {
            try {
                val conn = URL(u).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 8000
                val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val r = j.getJSONObject("usd").getDouble("egp")
                Store.saveRateFor(c, date, r)
                return r to true
            } catch (e: Exception) { }
        }
        return null
    }
}
