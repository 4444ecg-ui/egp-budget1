package com.example.budget

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var note: TextView
    private lateinit var log: TextView
    private var selDate = Store.today()

    private fun parse(s: String): Double? {
        val t = s.trim()
            .map { if (it in '٠'..'٩') ('0' + (it - '٠')) else it }
            .joinToString("").replace('٫', '.').replace('،', '.').replace(',', '.')
        return t.toDoubleOrNull()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        bar = findViewById(R.id.bar)
        note = findViewById(R.id.note)
        log = findViewById(R.id.log)
        val limitIn = findViewById<EditText>(R.id.limitIn)
        val egpIn = findViewById<EditText>(R.id.egpIn)
        val addBtn = findViewById<Button>(R.id.addBtn)

        if (Store.limit(this) > 0) limitIn.setText(Store.fmt(Store.limit(this)))

        findViewById<Button>(R.id.saveLimit).setOnClickListener {
            val v = parse(limitIn.text.toString())
            if (v == null || v <= 0) { toast("اكتب مبلغ صحيح بالدولار"); return@setOnClickListener }
            Store.setLimit(this, v); refresh()
        }

        val dateBtn = findViewById<Button>(R.id.dateBtn)
        val rateIn = findViewById<EditText>(R.id.rateIn)
        dateBtn.text = "تاريخ المصروف: " + selDate
        dateBtn.setOnClickListener {
            val q = selDate.split("-").map { it.toInt() }
            val dlg = DatePickerDialog(this, { _, y, m, d ->
                selDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                dateBtn.text = "تاريخ المصروف: " + selDate
            }, q[0], q[1] - 1, q[2])
            dlg.datePicker.maxDate = System.currentTimeMillis()
            dlg.show()
        }

        findViewById<Button>(R.id.cbeBtn).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.cbe.org.eg/en/economic-research/statistics/cbe-exchange-rates")))
        }

        addBtn.setOnClickListener {
            val egp = parse(egpIn.text.toString())
            if (egp == null || egp <= 0) { toast("اكتب مبلغ صحيح بالجنيه"); return@setOnClickListener }
            val manual = parse(rateIn.text.toString())
            val date = selDate
            addBtn.isEnabled = false
            thread {
                val r: Pair<Double, Boolean>? =
                    if (manual != null && manual > 0) manual to true else Rates.forDate(this, date)
                runOnUiThread {
                    if (r == null) {
                        toast("مفيش سعر متاح ليوم " + date + ". اكتب سعر الدولار يدوي (من البنك) في الخانة.")
                    } else {
                        Store.add(this, egp, r.first, date)
                        toast(Store.fmt(egp) + " ج.م = $" + Store.fmt(egp / r.first) + "  (سعر " + Store.fmt(r.first) + " يوم " + date + ")")
                        if (!r.second) toast("النت مش شغال: استخدمت آخر سعر محفوظ")
                        egpIn.text.clear(); rateIn.text.clear(); refresh()
                    }
                    addBtn.isEnabled = true
                }
            }
        }

        findViewById<Button>(R.id.undoBtn).setOnClickListener { Store.removeLast(this); refresh() }
        findViewById<Button>(R.id.statsBtn).setOnClickListener {
            startActivity(Intent(this, StatsActivity::class.java))
        }
        refresh()
    }

    private fun refresh() {
        val spent = Store.spentUsd(this)
        val limit = Store.limit(this)
        val pct = if (limit > 0) ((spent / limit) * 100).toInt().coerceIn(0, 100) else 0
        status.text = "صرفت هذا الشهر: $" + Store.fmt(spent) +
            (if (limit > 0) "\nمن الحد: $" + Store.fmt(limit) +
                "\nالمتبقي: $" + Store.fmt(limit - spent) + " (" + pct + "%)"
            else "\nالحد الشهري غير محدد")
        bar.progress = pct
        val col = Store.colorFor(pct)
        status.setTextColor(col)
        bar.progressTintList = ColorStateList.valueOf(col)
        val rate = Store.cachedRate(this)
        note.text = "إجمالي الشهر: " + Store.fmt(Store.spentEgp(this)) + " ج.م" +
            (if (rate != null) "\nآخر سعر: 1$ = " + Store.fmt(rate.second) + " ج.م (" + rate.first + ")" else "") +
            "\nأسعار الصرف: exchangerate-api.com"
        val ls = Store.lines(this)
        log.text = if (ls.isEmpty()) "مفيش مصروفات الشهر ده" else "مصروفات الشهر (" + ls.size + "):\n" + ls.joinToString("\n")
        BudgetWidget.refreshAll(this)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
