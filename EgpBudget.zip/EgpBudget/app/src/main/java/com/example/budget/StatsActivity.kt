package com.example.budget

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class StatsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)
        val sv = ScrollView(this)
        sv.addView(root)
        sv.setBackgroundColor(0xFFF4F6FA.toInt())
        setContentView(sv)

        fun tv(t: String, size: Float, bold: Boolean): TextView {
            val v = TextView(this)
            v.text = t; v.textSize = size
            if (bold) v.setTypeface(null, Typeface.BOLD)
            return v
        }

        val head = tv("مقارنة المصروفات الشهرية", 22f, true)
        head.setTextColor(0xFF1565C0.toInt())
        root.addView(head)
        val totals = Store.monthTotals(this)
        if (totals.isEmpty()) { root.addView(tv("مفيش بيانات لسه. أضف مصروفات الأول.", 15f, false)); return }

        val max = totals.maxOf { it.usd }
        val avg = totals.sumOf { it.usd } / totals.size
        val hi = totals.maxByOrNull { it.usd }!!
        val lo = totals.minByOrNull { it.usd }!!
        val sum = tv("متوسط الشهر: $" + Store.fmt(avg) + "\nأعلى شهر: " + hi.month + " ($" + Store.fmt(hi.usd) + ")" +
            "\nأقل شهر: " + lo.month + " ($" + Store.fmt(lo.usd) + ")", 15f, false)
        sum.setPadding(0, pad / 2, 0, pad / 2)
        root.addView(sum)

        val cur = Store.month()
        for (i in totals.indices.reversed()) {
            val st = totals[i]
            val prev = if (i > 0) totals[i - 1] else null
            val title = tv(st.month + (if (st.month == cur) "  (الشهر الحالي، لسه ما خلصش)" else ""), 16f, true)
            title.setPadding(0, pad / 2, 0, 0)
            title.setTextColor(0xFF1565C0.toInt())
            root.addView(title)
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            bar.max = 100
            bar.progressTintList = ColorStateList.valueOf(0xFF6A1B9A.toInt())
            bar.progress = if (max > 0) ((st.usd / max) * 100).toInt() else 0
            root.addView(bar)
            val line = "$" + Store.fmt(st.usd) + "  |  " + Store.fmt(st.egp) + " ج.م  |  " + st.count + " عملية"
            root.addView(tv(line, 14f, false))
            if (prev != null && prev.usd > 0) {
                val ch = (st.usd - prev.usd) / prev.usd * 100
                val c = tv((if (ch >= 0) "▲ " else "▼ ") + String.format(Locale.US, "%+.1f%%", ch) + " عن " + prev.month, 14f, true)
                c.setTextColor(if (ch >= 0) 0xFFC62828.toInt() else 0xFF2E7D32.toInt())
                root.addView(c)
            }
        }
        root.addView(tv("ملحوظة: القيم بالدولار محسوبة بسعر يوم كل مصروف.", 12f, false).also { it.setPadding(0, pad, 0, 0) })
    }
}
