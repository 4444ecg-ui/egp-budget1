package com.example.budget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Build
import android.widget.RemoteViews

class BudgetWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    companion object {
        fun refreshAll(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            m.getAppWidgetIds(ComponentName(ctx, BudgetWidget::class.java)).forEach { update(ctx, m, it) }
        }

        private fun update(ctx: Context, m: AppWidgetManager, id: Int) {
            val spent = Store.spentUsd(ctx)
            val limit = Store.limit(ctx)
            val pct = if (limit > 0) ((spent / limit) * 100).toInt().coerceIn(0, 100) else 0
            val v = RemoteViews(ctx.packageName, R.layout.widget_budget)
            v.setTextViewText(R.id.wMain, "$" + Store.fmt(spent) + " / $" + Store.fmt(limit))
            v.setTextViewText(R.id.wSub, "المتبقي: $" + Store.fmt(limit - spent) + "  (" + pct + "%)")
            v.setProgressBar(R.id.wBar, 100, pct, false)
            val col = Store.colorFor(pct)
            v.setTextColor(R.id.wMain, col)
            if (Build.VERSION.SDK_INT >= 31)
                v.setColorStateList(R.id.wBar, "setProgressTintList", ColorStateList.valueOf(col))
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.wRoot, pi)
            m.updateAppWidget(id, v)
        }
    }
}
